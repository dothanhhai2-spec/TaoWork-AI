import os
import time

# Lưu lịch sử thuyết trình giả lập
history = []

def create_presentation():
    topic = input("Nhập chủ đề thuyết trình: ")
    print(f"🔎 Đang phân tích chủ đề '{topic}' ...")
    time.sleep(2)
    print("✅ Thuyết trình đã được tạo thành công!\n")
    history.append(topic)

def view_history():
    if not history:
        print("📂 Chưa có thuyết trình nào trong lịch sử.\n")
    else:
        print("📂 Danh sách thuyết trình đã tạo:")
        for i, h in enumerate(history, 1):
            print(f"{i}. {h}")
        print("")

def main():
    while True:
        print("===== TaoWorks AI =====")
        print("1. Tạo thuyết trình mới")
        print("2. Xem lịch sử thuyết trình")
        print("3. Thoát")
        choice = input("Chọn chức năng (1-3): ")

        if choice == "1":
            create_presentation()
        elif choice == "2":
            view_history()
        elif choice == "3":
            print("👋 Cảm ơn bạn đã dùng TaoWorks AI!")
            break
        else:
            print("❌ Lựa chọn không hợp lệ, vui lòng thử lại.\n")

if __name__ == "__main__":
    main()
